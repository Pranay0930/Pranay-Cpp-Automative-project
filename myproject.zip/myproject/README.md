Necessary Dependencies Install to Run the Project

pip install djangorestframework

pip install boto3

Inorder to Initiate the SSO, run this command

aws sso login --profile MSCCLOUD-250738637992