from django.apps import AppConfig


class DynamoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dynamoapp'
